/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-b1bafff1'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "somiti-logo.png",
    "revision": "701b3aa1e2e94f613c882d657ee3b99a"
  }, {
    "url": "somiti-logo.jpg",
    "revision": "c6e3d43d132a828eb19624cb4bd63222"
  }, {
    "url": "somiti-banner.jpg",
    "revision": "801b181bf63026d5b6a9d9c80cdd6827"
  }, {
    "url": "registerSW.js",
    "revision": "402b66900e731ca748771b6fc5e7a068"
  }, {
    "url": "moncho-logo.png",
    "revision": "b1862644b46e32a0033f01e5f93edbd4"
  }, {
    "url": "manifest.json",
    "revision": "cc295a0af9eebac4e5cd2ce59e4a510e"
  }, {
    "url": "manifest-somiti.json",
    "revision": "b853a0c02a67889404c8d90bfaae7a49"
  }, {
    "url": "manifest-moncho.json",
    "revision": "cc295a0af9eebac4e5cd2ce59e4a510e"
  }, {
    "url": "logo.png",
    "revision": "b1862644b46e32a0033f01e5f93edbd4"
  }, {
    "url": "index.html",
    "revision": "20cb1ce9b577d16f9719fdb7a83da502"
  }, {
    "url": "icon-maskable-512.png",
    "revision": "1c9b390a5faa88cbc719bfdb91d0c1da"
  }, {
    "url": "icon-maskable-192.png",
    "revision": "78413b334448348903411e875e051ca6"
  }, {
    "url": "icon-512.png",
    "revision": "a361031dcbfd28077e003389547a49e3"
  }, {
    "url": "icon-192.png",
    "revision": "317619aee392f3f69718b9d1a86deb85"
  }, {
    "url": "favicon.ico",
    "revision": "0ee2f9b1f2d0117a76170c7410a7af77"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "ca3d84092840a278376d5124246ed7e2"
  }, {
    "url": "assets/index-COCl2hmb.js",
    "revision": null
  }, {
    "url": "assets/index-B4tBt5Xb.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "ca3d84092840a278376d5124246ed7e2"
  }, {
    "url": "favicon.ico",
    "revision": "0ee2f9b1f2d0117a76170c7410a7af77"
  }, {
    "url": "icon-192.png",
    "revision": "317619aee392f3f69718b9d1a86deb85"
  }, {
    "url": "icon-512.png",
    "revision": "a361031dcbfd28077e003389547a49e3"
  }, {
    "url": "icon-maskable-192.png",
    "revision": "78413b334448348903411e875e051ca6"
  }, {
    "url": "icon-maskable-512.png",
    "revision": "1c9b390a5faa88cbc719bfdb91d0c1da"
  }, {
    "url": "logo.png",
    "revision": "b1862644b46e32a0033f01e5f93edbd4"
  }, {
    "url": "manifest-moncho.json",
    "revision": "cc295a0af9eebac4e5cd2ce59e4a510e"
  }, {
    "url": "manifest.json",
    "revision": "cc295a0af9eebac4e5cd2ce59e4a510e"
  }, {
    "url": "moncho-logo.png",
    "revision": "b1862644b46e32a0033f01e5f93edbd4"
  }, {
    "url": "manifest.webmanifest",
    "revision": "e3e2acade26ecbd3c10d4429bf15f04e"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 20,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/images\.unsplash\.com\/.*/i, new workbox.StaleWhileRevalidate({
    "cacheName": "unsplash-image-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 30,
      maxAgeSeconds: 2592000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/\.(?:png|jpg|jpeg|svg|gif|webp)$/i, new workbox.CacheFirst({
    "cacheName": "static-image-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 60,
      maxAgeSeconds: 2592000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
